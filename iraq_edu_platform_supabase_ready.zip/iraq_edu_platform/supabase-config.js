// ضع بيانات مشروع Supabase هنا فقط.
// استخدم anon/public key وليس service_role key.
window.SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';
window.SUPABASE_ANON_KEY = 'YOUR_ANON_PUBLIC_KEY';
