create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz default now()
);

create table if not exists public.content (
  id uuid primary key default gen_random_uuid(),
  branch text not null check (branch in ('scientific','literary')),
  type text not null check (type in ('lecture','pdf','quiz','announcement')),
  title text not null,
  description text,
  url text,
  created_at timestamptz default now()
);

alter table public.admin_users enable row level security;
alter table public.content enable row level security;

drop policy if exists "admins read own row" on public.admin_users;
create policy "admins read own row" on public.admin_users for select to authenticated using (user_id = auth.uid());

drop policy if exists "public read content" on public.content;
create policy "public read content" on public.content for select to anon, authenticated using (true);

drop policy if exists "admins insert content" on public.content;
create policy "admins insert content" on public.content for insert to authenticated with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

drop policy if exists "admins update content" on public.content;
create policy "admins update content" on public.content for update to authenticated using (exists (select 1 from public.admin_users a where a.user_id = auth.uid())) with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

drop policy if exists "admins delete content" on public.content;
create policy "admins delete content" on public.content for delete to authenticated using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));
