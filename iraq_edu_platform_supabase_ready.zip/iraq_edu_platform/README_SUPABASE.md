# منصة العراق التعليمية — إعداد Supabase

## 1) إنشاء المشروع
أنشئ مشروعًا جديدًا في Supabase.

## 2) قاعدة البيانات
افتح SQL Editor والصق محتوى `supabase_schema.sql` ثم نفّذه.

## 3) إعداد البريد
من Authentication > Providers > Email فعّل Email.
أنشئ مستخدم المدير من Authentication > Users، ثم ضع بريده في جدول `admin_users` عبر SQL:

insert into public.admin_users (user_id) values ('USER_UUID_HERE');

## 4) مفاتيح المشروع
انسخ Project URL و anon/public key إلى `supabase-config.js`.

> لا تضع service_role key في الموقع أو GitHub.

## 5) التشغيل
يمكن رفع المجلد كاملًا على Netlify أو أي استضافة static. افتح `admin.html` لتسجيل دخول المدير، و`index.html` للطلاب.
